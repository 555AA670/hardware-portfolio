# STM32G474 四开关电源 Altium 工程

使用 Altium Designer 打开 FSBB.PrjPcb。

包含 1 份 PCB、5 张原理图、符号库、封装库和集成库。工程文档列表已整理为包内相对路径。

- FSW.PcbDoc
- FSW.SchDoc
- power.SchDoc
- auxiliary power supply.SchDoc
- sense.SchDoc
- NTC.SchDoc
- FSW.SchLib、FSW.PcbLib、FSW.IntLib、FSW.LibPkg
