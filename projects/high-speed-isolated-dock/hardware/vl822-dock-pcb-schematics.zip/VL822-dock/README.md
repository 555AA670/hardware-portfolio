# VL822 高速加隔离拓展坞

设计文件包含 PCB、4 张原理图、符号库和封装库，使用 Altium Designer 打开。

## 已知问题

- USB-A 连接器选型未考虑 10 Gbps 适配，导致该速率下信号完整性裕量不足，需更换为支持 10 Gbps 的型号。
- TPS2121 切换供电时掉识别的问题，已通过修改切换阈值的分压电阻阻值解决。
- CH347F 功能尚未验证。

## 文件清单

- 扩展坞.PcbDoc：PCB。
- VL822.SchDoc：USB Hub 与上游接口。
- ETH.SchDoc：以太网。
- ISO_USB.SchDoc：隔离 USB 与 CH347F。
- Power.SchDoc：电源。
- Schlib2.SchLib、PcbLib2.PcbLib：符号库与封装库。
