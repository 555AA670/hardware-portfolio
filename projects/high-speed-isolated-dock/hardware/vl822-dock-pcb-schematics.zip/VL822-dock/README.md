# VL822 高速加隔离拓展坞

这里有 PCB、4 张原理图、符号库和封装库，用 Altium Designer 打开。

有两个地方要注意：

- 这版高速 USB-A 座子选错了，不支持 10 Gbps，要换专门支持 10 Gbps 的型号。
- CH347F 还没验证。

文件：

- 扩展坞.PcbDoc：PCB。
- VL822.SchDoc：USB Hub 和上游接口。
- ETH.SchDoc：网口。
- ISO_USB.SchDoc：隔离 USB 和 CH347F。
- Power.SchDoc：电源。
- Schlib2.SchLib、PcbLib2.PcbLib：符号库和封装库。
