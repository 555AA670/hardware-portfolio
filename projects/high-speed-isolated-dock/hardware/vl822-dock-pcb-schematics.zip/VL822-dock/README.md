# VL822 高速加隔离拓展坞设计文件

## 当前版本说明

- 高速 USB-A 连接器选型有误，当前型号不支持 10 Gbps（USB 3.2 Gen 2）。复刻或改版时需更换为明确标称支持 10 Gbps 的 USB-A 连接器，并核对封装和焊盘。该问题针对非隔离侧的高速 USB-A，隔离侧 USB-A 为 USB 2.0。
- CH347F 实际功能尚未验证。现有截图仅记录 USB 设备和双串口枚举，不能作为串口收发、SPI、I2C、JTAG 等功能测试通过的依据。
- 项目页中的 10 Gbps 日志保留为一次链路协商记录，当前连接器仍须按上述要求更换。

## 文件清单

- 扩展坞.PcbDoc：PCB 源文件。
- VL822.SchDoc：USB Hub 与上游接口原理图。
- ETH.SchDoc：以太网原理图。
- ISO_USB.SchDoc：隔离 USB 与调试接口原理图。
- Power.SchDoc：电源原理图。
- Schlib2.SchLib、PcbLib2.PcbLib：现有本地符号库和封装库。

使用 Altium Designer 打开上述 PCB 与原理图源文件。文件包保留原始设计文件，未对连接器选型或电路进行修改。
